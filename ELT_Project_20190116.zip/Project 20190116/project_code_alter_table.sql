SELECT tdtrpnum, trpmiles, whyfrom,trippurp,whytrp1s, hhfaminc, tdaydate FROM trippub; 
---update/rename columns 
ALTER TABLE trippub RENAME COLUMN tdtrpnum days_tripping(int), 
RENAME COLUMN trpmiles trip_miles(int), RENAME COLUMN whyfrom trip_purpose(int),
RENAME COLUMN trippurp trip_description(varchar(50)), RENAME COLUMN whytrp1s trip_summary(int),
RENAME COLUMN hhfaminc family_income(int), RENAME COLUMN tdaydate trip_date(int);


